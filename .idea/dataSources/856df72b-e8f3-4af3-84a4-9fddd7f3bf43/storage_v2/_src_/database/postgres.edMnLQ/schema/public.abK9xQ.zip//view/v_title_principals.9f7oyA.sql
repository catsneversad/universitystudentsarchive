create view v_title_principals(tconst, ordering, nconst, category, job, characters) as
SELECT title_principals.tconst,
       title_principals.ordering::integer AS ordering,
       title_principals.nconst,
       title_principals.category,
       CASE
           WHEN title_principals.job = '\N'::text THEN NULL::text
           ELSE title_principals.job
           END                            AS job,
       CASE
           WHEN title_principals.characters = '\N'::text THEN NULL::text
           ELSE title_principals.characters
           END                            AS characters
FROM title_principals;

alter table v_title_principals
    owner to postgres;

