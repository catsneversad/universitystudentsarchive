create view v_title_basics
            (tconst, title_type, primary_title, original_title, is_adult, start_year, end_year, runtime_minutes,
             genres) as
SELECT title_basics.tconst,
       title_basics."titleType"     AS title_type,
       title_basics."primaryTitle"  AS primary_title,
       title_basics."originalTitle" AS original_title,
       CASE
           WHEN title_basics."isAdult" = '\N'::text THEN NULL::text
           ELSE title_basics."isAdult"
           END::boolean             AS is_adult,
       CASE
           WHEN title_basics."startYear" = '\N'::text THEN NULL::text
           ELSE title_basics."startYear"
           END::integer             AS start_year,
       CASE
           WHEN title_basics."endYear" = '\N'::text THEN NULL::text
           ELSE title_basics."endYear"
           END::integer             AS end_year,
       CASE
           WHEN title_basics."runtimeMinutes" = '\N'::text THEN NULL::text
           ELSE title_basics."runtimeMinutes"
           END::integer             AS runtime_minutes,
       CASE
           WHEN title_basics.genres = '\N'::text THEN NULL::text
           ELSE title_basics.genres
           END                      AS genres
FROM title_basics;

alter table v_title_basics
    owner to postgres;

