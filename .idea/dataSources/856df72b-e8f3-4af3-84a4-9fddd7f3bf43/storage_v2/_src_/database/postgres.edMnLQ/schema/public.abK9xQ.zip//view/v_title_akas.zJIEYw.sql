create view v_title_akas (title_id, ordering, title, region, language, types, attributes, is_original_title) as
SELECT title_akas."titleId"         AS title_id,
       title_akas.ordering::integer AS ordering,
       title_akas.title,
       CASE
           WHEN title_akas.region = '\N'::text THEN NULL::text
           ELSE title_akas.region
           END                      AS region,
       CASE
           WHEN title_akas.language = '\N'::text THEN NULL::text
           ELSE title_akas.language
           END                      AS language,
       CASE
           WHEN title_akas.types = '\N'::text THEN NULL::text
           ELSE title_akas.types
           END                      AS types,
       CASE
           WHEN title_akas.attributes = '\N'::text THEN NULL::text
           ELSE title_akas.attributes
           END                      AS attributes,
       CASE
           WHEN title_akas."isOriginalTitle" = '\N'::text THEN NULL::text
           ELSE title_akas."isOriginalTitle"
           END::boolean             AS is_original_title
FROM title_akas;

alter table v_title_akas
    owner to postgres;

