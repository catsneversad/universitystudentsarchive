create view v_title_ratings(tconst, average_rating, num_votes) as
SELECT title_ratings.tconst,
       CASE
           WHEN title_ratings."averageRating" = '\N'::text THEN NULL::text
           ELSE title_ratings."averageRating"
           END::double precision AS average_rating,
       CASE
           WHEN title_ratings."numVotes" = '\N'::text THEN NULL::text
           ELSE title_ratings."numVotes"
           END::integer          AS num_votes
FROM title_ratings;

alter table v_title_ratings
    owner to postgres;

