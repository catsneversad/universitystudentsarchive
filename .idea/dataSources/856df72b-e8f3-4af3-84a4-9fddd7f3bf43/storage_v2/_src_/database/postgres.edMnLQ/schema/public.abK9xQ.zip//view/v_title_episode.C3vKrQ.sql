create view v_title_episode(tconst, parent_tconst, season_number, episode_number) as
SELECT title_episode.tconst,
       title_episode."parentTconst" AS parent_tconst,
       CASE
           WHEN title_episode."seasonNumber" = '\N'::text THEN NULL::text
           ELSE title_episode."seasonNumber"
           END::integer             AS season_number,
       CASE
           WHEN title_episode."episodeNumber" = '\N'::text THEN NULL::text
           ELSE title_episode."episodeNumber"
           END::integer             AS episode_number
FROM title_episode;

alter table v_title_episode
    owner to postgres;

