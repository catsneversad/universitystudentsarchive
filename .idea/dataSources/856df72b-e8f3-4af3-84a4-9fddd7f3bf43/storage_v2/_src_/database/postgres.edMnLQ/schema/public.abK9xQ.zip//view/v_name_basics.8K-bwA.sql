create view v_name_basics (nconst, primary_name, birth_year, death_year, primary_profession, known_for_titles) as
SELECT name_basics.nconst,
       name_basics."primaryName"       AS primary_name,
       CASE
           WHEN name_basics."birthYear" = '\N'::text THEN NULL::text
           ELSE name_basics."birthYear"
           END::integer                AS birth_year,
       CASE
           WHEN name_basics."deathYear" = '\N'::text THEN NULL::text
           ELSE name_basics."deathYear"
           END::integer                AS death_year,
       name_basics."primaryProfession" AS primary_profession,
       CASE
           WHEN name_basics."knownForTitles" = '\N'::text THEN NULL::text
           ELSE name_basics."knownForTitles"
           END                         AS known_for_titles
FROM name_basics;

alter table v_name_basics
    owner to postgres;

