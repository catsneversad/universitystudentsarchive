create view v_title_crew(tconst, directors, writers) as
SELECT title_crew.tconst,
       CASE
           WHEN title_crew.directors = '\N'::text THEN NULL::text
           ELSE title_crew.directors
           END AS directors,
       CASE
           WHEN title_crew.writers = '\N'::text THEN NULL::text
           ELSE title_crew.writers
           END AS writers
FROM title_crew;

alter table v_title_crew
    owner to postgres;

