create function sumof3or5(n numeric) returns bigint
    language plpgsql
as
$$
declare
    res numeric := 0;
begin
if (n % 3) = 0 or (n % 5) = 0 then
    res := res + 1;
end if;
return res + sumof3or5 (n-1);
end;
$$;

alter function sumof3or5(numeric) owner to postgres;

