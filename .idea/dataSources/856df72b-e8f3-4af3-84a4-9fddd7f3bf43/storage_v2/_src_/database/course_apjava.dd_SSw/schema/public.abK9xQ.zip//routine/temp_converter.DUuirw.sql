create function temp_converter(temp numeric, to_fahr boolean DEFAULT true) returns numeric
    language plpgsql
as
$$
declare
    res numeric;
begin
if to_fahr then
    res := (temp * 9/5) + 32;
else
    res := (temp - 32) * 5/9;
end if;
return round(res, 2);
end;
$$;

alter function temp_converter(numeric, boolean) owner to postgres;

