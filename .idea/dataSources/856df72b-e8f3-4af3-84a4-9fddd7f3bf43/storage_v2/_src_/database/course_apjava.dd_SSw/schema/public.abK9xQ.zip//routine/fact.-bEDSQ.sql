create function fact(n integer) returns bigint
    language plpgsql
as
$$
declare
    res bigint;
begin
if n = 0 then
    res := 1;
else
    res := n * fact(n-1);
end if;
return res;
end;
$$;

alter function fact(integer) owner to postgres;

