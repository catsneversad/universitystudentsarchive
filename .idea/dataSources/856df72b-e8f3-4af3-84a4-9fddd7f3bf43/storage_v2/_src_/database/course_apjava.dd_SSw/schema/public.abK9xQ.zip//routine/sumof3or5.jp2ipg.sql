create function sumof3or5(n integer) returns integer
    language plpgsql
as
$$
declare
    res integer := 0;
begin
    if (n < 3) then
        res := 0 ;
    end if;
    for counter in 3..n-1
        loop
            if (MOD(counter, 3) = 0 or MOD(counter, 5) = 0) then
                res := res + counter;
            end if;

            counter := counter + 1;
        end loop;
    return res;
end;
$$;

alter function sumof3or5(integer) owner to postgres;

