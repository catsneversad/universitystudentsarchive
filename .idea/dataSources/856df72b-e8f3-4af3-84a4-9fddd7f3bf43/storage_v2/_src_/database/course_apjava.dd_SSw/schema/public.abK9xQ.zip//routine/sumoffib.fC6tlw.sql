create function sumoffib() returns bigint
    language plpgsql
as
$$
declare
    res     bigint := 0;
    f1      bigint := 0;
    f2      bigint := 1;
    fhelper bigint := 0;
begin
    while f2 < 4000000
        loop
            if (MOD(f2, 2) = 0) then
                res := res + f2;
            end if;

            fhelper := f2;
            f2 := f2 + f1;
            f1 := fhelper;
        end loop;
    return res;
end;
$$;

alter function sumoffib() owner to postgres;

